DROP TABLE #__bibliant;
