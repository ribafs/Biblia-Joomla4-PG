<?php
/**
 * @ install.bibliant.php
 * @author-name Ribamar FS
 * @copyright	Copyright (C) 2012 Ribamar FS.
 * @license GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install()
{
	?>
	<div class="header">Parabéns, o Componente Versículo do dia (NT) está instalado!</div>
	<p>
		Agora a cada chagada ao site o visitante será recebido por um versículo diferente do novo testamento.
	</p>
	<?php
}

?>
